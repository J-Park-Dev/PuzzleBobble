#pragma once
#define _USE_MATH_DEFINES
#include <GL/glut.h>
#include <math.h>
#include "Control.h"

class PathLaser
{
private:

public:
	void draw(int angle);
};

